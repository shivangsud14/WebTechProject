<?php
$userid = filter_input(INPUT_POST ,'fname');
$username = filter_input(INPUT_POST ,'userid');
$email = filter_input(INPUT_POST ,'email');
$bday = filter_input(INPUT_POST ,'Bday');
$occ = filter_input(INPUT_POST ,'occupation');
$password = filter_input(INPUT_POST ,'psw');
$useridold = filter_input(INPUT_POST ,'idid');

$servername = "localhost";
$dbusername = "root"; 
$dbpassword = "";
$dbname = "shivang";

// Create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "UPDATE ftable SET userid='$username',fullname='$userid',Email='$email',dob='$bday',occupation='$occ',passwords='$password' WHERE userid='$useridold'";


if (mysqli_query($conn, $sql)) {
  //  fun();
    $msg="Information Updated! Please Log-in";
    echo "<script type='text/javascript'>alert('$msg');
    window.location = ' http://localhost/wtpro/firstpage/1.html';
    </script>";
  //  if(1)
    //{
      //  header("Location: http://localhost/wtpro/firstpage/1.html");
    //}

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";

mysqli_close($conn);
?>
