<?php
<!DOCTYPE html>
echo "<html>"
echo "<title>home page</title>"
echo "<meta charset="UTF-8">"
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="1.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="./style.css">
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style>
<body class="basetech-light-grey">

<!-- Top container -->
<!-- <div class="basetech-bar basetech-top basetech-amber basetech-large" style="z-index:4">
  <span class="basetech-bar-item bastech-left"><a href="#">ABOUT</a></span>
  <span class="basetech-bar-item basetech-right"><a href="1.html"><img src="logo.png" alt="logo" style="height:40px; width:100px"></img></a></span>
</div> -->
<div class="basetech-top" style="z-index:8">
  <div class="basetech-bar basetech-amber basetech-card basetech-left-align basetech-large" style="z-index:8">
    <a class="basetech-bar-item basetech-button basetech-hide-medium basetech-hide-large basetech-right basetech-padding-large basetech-hover-white basetech-large basetech-amber" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="basetech-bar-item basetech-button basetech-padding-large basetech-white">Home</a>
   echo "<a href="C:\Users\vighnesh b k\Desktop\web tech projrct\about\1.html" class="basetech-bar-item basetech-button basetech-hide-small basetech-padding-large basetech-hover-white">About</a>"
    <a href="#" class="basetech-bar-item basetech-button basetech-hide-small basetech-padding-large basetech-hover-white">Privacy Policy</a>
    <a href="#" class="basetech-bar-item basetech-button basetech-hide-small basetech-padding-large basetech-hover-white">FAQ</a>
  </div>

  <!-- Navbar on small screens -->
  <div id="navDemo" class="basetech-bar-block basetech-white basetech-hide basetech-hide-large basetech-hide-medium basetech-large" style="z-index:8;">
    <a href="C:\Users\vighnesh b k\Desktop\web tech projrct\about\1.html" class="basetech-bar-item basetech-button basetech-padding-large">About</a>

    <a href="#" class="basetech-bar-item basetech-button basetech-padding-large">Privacy Policy</a>
    <a href="#" class="basetech-bar-item basetech-button basetech-padding-large">FAQ</a>
  </div>
</div>






<!-- Sidebar/menu -->
<nav class="basetech-sidebar basetech-collapse basetech-black basetech-animate-left" style="width:300px;" id="mySidebar"><br>
  <div class="basetech-container basetech-row">
    <div class="basetech-col s4">
      <img src="avtar.png" class="basetech-circle basetech-margin-right" style="width:46px">
    </div>
    <div class="basetech-col s8 basetech-bar">
      <span>Welcome, <strong>#####</strong></span><br>
    </div>
  </div>
  <hr>
  <div class="basetech-container">
    <h5>My Account</h5>
  </div>
  <div class="basetech-bar-block">
    <!-- <a href="#" class="basetech-bar-item basetech-button basetech-padding-16 basetech-hide-large basetech-dark-grey basetech-hover-black" onclick="basetech_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a> -->
    <p class="basetech-bar-item   "><i class="fa fa-user fa-fw"></i>  User Id: ########</p>
    <p class="basetech-bar-item  basetech-padding"><i class="fa fa-birthday-cake fa-fw"></i>  Date of Birth: ######</p>
      <p class="basetech-bar-item  basetech-padding"><i class="fa fa-building fa-fw"></i>  Occupation: ######</p>

        <button class="basetech-bar-item basetech-button basetech-padding" onclick="document.getElementById('id01').style.display='block'"><i class="fa fa-cog fa-fw"></i>change account info</button>

  </div>
</nav>


<!-- Overlay effect when opening sidebar on small screens -->
<div class="basetech-overlay basetech-hide-large basetech-animate-opacity" onclick="basetech_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="basetech-main basetech-sand" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="basetech-container basetech-khaki" style="padding-top:22px">
    <p class="basetech-xlarge"><b><i class="fa fa-feed"></i> Lets..Go...</b></p>
  </header>

  <div class="basetech-row-padding basetech-margin-bottom basetech-khaki">
    <style>
    #div1 {
    width: 350px;
    height: 70px;
    padding: 10px;
    border: 1px solid #aaaaaa;
  }
  #drag1:hover{
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);

  }
    ul li {

        display: inline-block;
    }
    ul li a {
        padding: 5px;
        display: inline-block;
        border: 1px solid #f2f2f2;
    }
    ul li a img {
        width: 250px;
        height: 125px;
        /* display: block; */
    }
    ul li a:hover img {
        transform: scale(1.5);
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    }
</style>
    <ul>
      <li><a href="#"><img src="f1.png" alt="Club Card"></a></li>
      <li><a href="#"><img src="f2.png" alt="Diamond Card"></a></li>
      <li><a href="#"><img src="f3.png" alt="Spade Card"></a></li>
      <li><a href="#"><img src="f4.png" alt="Heart Card"></a></li>
</ul>
  </div>

  <div class="basetech-container" style="padding-top:22px">
    <p class="basetech-xlarge"><b><i class="fa fa-gamepad"></i> Can You Solve This.....</b></p>
  </div>

  <div class="mainBox">
      	<div class="box" id="id_0"></div>
          <div class="box" id="id_1"></div>
          <div class="box" id="id_2"></div>
          <div class="box" id="id_3"></div>
          <div class="box" id="id_4"></div>
          <div class="box" id="id_5"></div>
          <div class="box" id="id_6"></div>
          <div class="box" id="id_7"></div>
          <div class="box" id="id_8"></div>
          <div class="box" id="id_9"></div>
          <div class="box" id="id_10"></div>
          <div class="box" id="id_11"></div>
          <div class="box" id="id_12"></div>
          <div class="box" id="id_13"></div>
          <div class="box" id="id_14"></div>
          <div class="activeBox" id="id_15"></div>

      </div>
  <div id="timeLeft">
    <div>
      <span class="minutes"></span>
      <div class="smalltext">Minutes</div>
      <h5>Time</h5>
    </div>
    <div>
      <span class="seconds"></span>
      <div class="smalltext">Seconds</div>
      <h5>Left</h5>
    </div>
    <div id="demoPic"></div>
  </div>

    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
  <script  src="./script.js"></script>


  <div class="basetech-container basetech-padding-32 basetech-center basetech-opacity basetech-dark-grey">
    <div class="basetech-xlarge ">
      <i class="fa fa-facebook-official basetech-hover-opacity"></i>
      <i class="fa fa-instagram basetech-hover-opacity"></i>
      <i class="fa fa-snapchat basetech-hover-opacity"></i>
      <i class="fa fa-pinterest-p basetech-hover-opacity"></i>
      <i class="fa fa-twitter basetech-hover-opacity"></i>
      <i class="fa fa-linkedin basetech-hover-opacity"></i>
   </div>
   <p>Powered by <a href="#" >BaseTech</a></p>
 </div>


  <!-- End page content -->
</div>
<div id="id01" class="basetech-modal">
    <div class="basetech-modal-content basetech-card-4 basetech-animate-zoom " style="max-width:600px">

      <div class="basetech-center"><br>
        <span onclick="document.getElementById('id01').style.display='none'" class="basetech-button basetech-xlarge basetech-transparent basetech-display-topright" title="Close Modal">×</span>
        <p class="basetech-circle basetech-margin-top basetech-dark-grey">EDIT ACCOUNT</p>
      </div>

      <form class="basetech-container basetech-light-grey " action="">
        <div class="basetech-section">
          <label><b>User Name</b></label>
          <input class="basetech-input basetech-border basetech-margin-bottom" type="text" placeholder="#############" name="username"  required>
          <label><b>UserId</b></label>
          <input class="basetech-input basetech-border basetech-margin-bottom" type="text" placeholder="##########" name="userid" required>
          <label><b>Date of Birth</b></label><br>
          <input  type="date" name="Bday" required><br><br>
          <label><b>Occupation</b></label>
          <input class="basetech-input basetech-border basetech-margin-bottom" type="text" placeholder="###########" name="occupation" required>
          <label><b>Password</b></label>
          <input class="basetech-input basetech-border" type="password" placeholder="###########" name="psw" required>
          <button class="basetech-button basetech-block basetech-green basetech-section basetech-padding" type="submit">CHANGE</button>
          <!-- <input class="basetech-check basetech-margin-top" type="checkbox" checked="checked"> Remember me -->
        </div>
      </form>

      <div class="basetech-container basetech-border-top basetech-padding-16 basetech-light-grey">
        <button onclick="document.getElementById('id01').style.display='none'" type="button" class="basetech-button basetech-red">Cancel</button>
      </div>

    </div>
  </div>

<script>
// Get the Sidebar
var mySidebar = document.getElementById("mySidebar");

// Get the DIV with overlay effect
var overlayBg = document.getElementById("myOverlay");

// Toggle between showing and hiding the sidebar, and add overlay effect
function basetech_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
    overlayBg.style.display = "none";
  } else {
    mySidebar.style.display = 'block';
    overlayBg.style.display = "block";
  }
}

// Close the sidebar with the close button
function basetech_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}

function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("basetech-show") == -1) {
    x.className += " basetech-show";
  } else {
    x.className = x.className.replace(" basetech-show", "");
  }
}

function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("basetech-show") == -1) {
    x.className += " basetech-show";
  } else {
    x.className = x.className.replace(" basetech-show", "");
  }
}





</script>

</body>
</html>
?>