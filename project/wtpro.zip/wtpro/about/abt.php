<!DOCTYPE html>
<html>
<title>About</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="1.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}

body, html {
  height: 100%;
  line-height: 1.8;
}

/* Full height image header */
.bgimg-1 {
  background-position: center;
  background-size: cover;
  background-image: url("top.jpg");
  min-height: 70%;
}

.basetech-bar .basetech-button {
  padding: 16px;
}
</style>
<body>
    <script>
      function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c;
    if(ca[i]==='+')
      {
        c='_';
      }
    else{
      c = ca[i];
    }
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
     
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
      </script>
<!-- Navbar (sit on top) -->
<div class="basetech-top">
  <div class="basetech-bar basetech-amber basetech-card" id="myNavbar">
    <a href="#home" class="basetech-bar-item basetech-button basetech-wide"><img src="logo.png" style="height:30px"></img></a>
    <!-- Right-sided navbar links -->
    <div class="basetech-left basetech-hide-small">
        <script>
            var x=getCookie('username');
            if(x==="")
            {
                var link="http://localhost/wtpro/firstpage/1.html";
            }
            else{
              var link="http://localhost/wtpro/homepage/1.html";
            }
        </script>   
      <a href="<?php echo"<script>document.write(link);</script>"?>" class="basetech-bar-item basetech-button">HOME</a>
        
      <a href="#team" class="basetech-bar-item basetech-button"><i class="fa fa-user"></i> TEAM</a>
      <a href="#contact" class="basetech-bar-item basetech-button"><i class="fa fa-envelope"></i> CONTACT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="basetech-bar-item basetech-button basetech-right basetech-hide-large basetech-hide-medium" onclick="basetech_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<nav class="basetech-sidebar basetech-bar-block basetech-black basetech-card basetech-animate-left basetech-hide-medium basetech-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="basetech_close()" class="basetech-bar-item basetech-button basetech-large basetech-padding-16">Close ×</a>
  <a href="C:\Users\vighnesh b k\Desktop\web tech projrct\first page\1.html" onclick="basetech_close()" class="basetech-bar-item basetech-button">HOME</a>
  <a href="#team" onclick="basetech_close()" class="basetech-bar-item basetech-button">TEAM</a>
  <a href="#contact" onclick="basetech_close()" class="basetech-bar-item basetech-button">CONTACT</a>
</nav>

<!-- Header with full-height image -->
<header class="bgimg-1 basetech-display-container basetech-grayscale-min" id="home">
  <div class="basetech-display-left basetech-text-white" style="padding:48px">
    <span class="basetech-jumbo basetech-hide-small">Kick start your project with us...</span><br>
    <span class="basetech-xxlarge basetech-hide-large basetech-hide-medium">Kick start your project with us...</span><br>
    <span class="basetech-large">innovation from the depth...</span>
    <p><a href="#about" class="basetech-button basetech-white basetech-padding-large basetech-large basetech-margin-top basetech-opacity basetech-hover-opacity-off">Learn more and start today</a></p>
  </div>
  <div class="basetech-display-bottomleft basetech-text-grey basetech-large" style="padding:24px 48px">
    <i class="fa fa-facebook-official basetech-hover-opacity"></i>
    <i class="fa fa-instagram basetech-hover-opacity"></i>
    <!-- <i class="fa fa-snapchat basetech-hover-opacity"></i> -->
    <!-- <i class="fa fa-pinterest-p basetech-hover-opacity"></i> -->
    <i class="fa fa-twitter basetech-hover-opacity"></i>
    <!-- <i class="fa fa-linkedin basetech-hover-opacity"></i> -->
  </div>
</header>

<!-- About Section -->
<div class="basetech-container" style="padding:128px 16px" id="about">
  <h3 class="basetech-center">ABOUT THE COMPANY</h3>
  <p class="basetech-center basetech-large">Key features of our company</p>
  <div class="basetech-row-padding basetech-center" style="margin-top:64px">
    <div class="basetech-third">
      <i class="fa fa-desktop basetech-margin-bottom basetech-jumbo basetech-center"></i>
      <p class="basetech-large">Responsive</p>
      <p>For any work to be done just right without
          wasting time you need others help and
          ideas .This happens through Interaction. We as
          Company give you the platform to not just for
          learning new things but also to interact with the
          Professionals and put forth your ideas too
          which helps you to learn better :)</p>
    </div>
    <div class="basetech-third">
      <i class="fa fa-heart basetech-margin-bottom basetech-jumbo"></i>
      <p class="basetech-large">Motto</p>
      <p>We believe in empowering Women
          Any women across the globe can access this
          page and interact with several other women
          They come together Cook something great,
          Share something amazing and make their lives
          a little more fun and give them hope for a better
          tomorrow</p>
    </div>

    <div class="basetech-third">
      <i class="fa fa-cog basetech-margin-bottom basetech-jumbo"></i>
      <p class="basetech-large">Support</p>
      <p>We as a Company Provide you with a platform to showcase your talent in cooking , Kitty Parties etc. we also provide you  the Professional help  whenever you want to and you can also Interact with them and make your life much easier in the field of being an Amazing Housewife.</p>
    </div>
  </div>
</div>



<!-- Team Section -->
<div class="basetech-container" style="padding:128px 16px" id="team">
  <h3 class="basetech-center">OUR TEAM</h3>
  <p class="basetech-center basetech-large">THE REASON YOUR SEEING THIS ...</p>
  <div class="basetech-row-padding basetech-grayscale" style="margin-top:64px">
    <div class="basetech-col l4 m6 basetech-margin-bottom">
      <div class="basetech-card basetech-lime">
        <img src="VBK.jpg" alt="VIGHNESH BK" style="width:50% ">
        <div class="basetech-container">
          <h3>Vighnesh BK</h3>
          <p class="basetech-opacity">Founder</p>
          <p>Web Developer</p>
          <p><button class="basetech-button basetech-light-grey basetech-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>
    <div class="basetech-col l4 m6 basetech-margin-bottom">
      <div class="basetech-card">
        <img src="SHIVANG.jpg" alt="Shivang Sud" style="width:50%">
        <div class="basetech-container">
          <h3>Shivang Sud</h3>
          <p class="basetech-opacity">Founder</p>
          <p>Web Developer</p>
          <p><button class="basetech-button basetech-light-grey basetech-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>
    <div class="basetech-col l4 m6 basetech-margin-bottom">
      <div class="basetech-card basetech-lime" >
        <img src="SAGAR.jpg" alt="Sagar" style="width:50%">
        <div class="basetech-container">
          <h3>Sagar S Pai</h3>
          <p class="basetech-opacity">Founder</p>
          <p>Web Developer</p>
          <p><button class="basetech-button basetech-light-grey basetech-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>

    </div>
  </div>
</div>

<!-- Promo Section "Statistics" -->
<div class="basetech-container basetech-row basetech-center basetech-amber basetech-padding-64">

  <div class="basetech-third">
    <span class="basetech-xxlarge">55+</span>
    <br>Projects Done
  </div>
  <div class="basetech-third">
    <span class="basetech-xxlarge">89+</span>
    <br>Happy Clients
  </div>
  <div class="basetech-tird">
    <span class="basetech-xxlarge">150+</span>
    <br>Meetings
  </div>
</div>





<!-- Skills Section -->
<div class="basetech-container basetech-light-grey basetech-padding-64">
  <div class="basetech-row-padding">
    <div class="basetech-col m6">
      <h3>Our Skills.</h3>
      <!-- <p>Dedicated team of three </p> -->
      <!-- <p>Motivated to improve the society</p> -->
    </div>
    <div class="basetech-col m6">
      <!-- <p class="basetech-wide"><i class="fa fa-camera basetech-margin-right"></i>Photography</p> -->
      <!-- <div class="basetech-grey">
        <div class="basetech-container basetech-dark-grey basetech-center" style="width:90%">90%</div>
      </div> -->
      <p class="basetech-wide"><i class="fa fa-desktop basetech-margin-right"></i>Web Design</p>
      <div class="basetech-amber">
        <div class="basetech-container basetech-black basetech-center" style="width:85%">85%</div>
      </div>
      <p class="basetech-wide"><i class="fa fa-desktop basetech-margin-right"></i>Computer Applictaions</p>
      <div class="basetech-amber">
        <div class="basetech-container basetech-black basetech-center" style="width:75%">75%</div>
      </div>
    </div>
  </div>
</div>



<!-- Contact Section -->
<div class="basetech-container basetech-dark-grey" style="padding:10px 6px" id="contact">
  <h3 class="basetech-center">CONTACT</h3>

  <div style="margin-top:10px">
    <p><i class="fa fa-map-marker fa-fw basetech-xxlarge basetech-margin-left"></i>Banglore,India</p>
    <p><i class="fa fa-phone fa-fw basetech-xxlarge basetech-margin-left"></i> Phone: +91 9972282476</p>
    <p><i class="fa fa-envelope fa-fw basetech-xxlarge basetech-margin-left"> </i> Email: basetech@gmail.com</p>
    <br>


  </div>
</div>

<!-- Footer -->
<footer class="basetech-center basetech-black basetech-padding-64">
  <a href="#home" class="basetech-button basetech-light-grey"><i class="fa fa-arrow-up basetech-margin-right"></i>To the top</a>
  <div class="basetech-xlarge basetech-section">
    <i class="fa fa-facebook-official basetech-hover-opacity"></i>
    <i class="fa fa-instagram basetech-hover-opacity"></i>
    <!-- <i class="fa fa-snapchat basetech-hover-opacity"></i> -->
    <!-- <i class="fa fa-pinterest-p basetech-hover-opacity"></i> -->
    <i class="fa fa-twitter basetech-hover-opacity"></i>
    <!-- <i class="fa fa-linkedin basetech-hover-opacity"></i> -->
  </div>
  <p>Powered by <a href="#" title="basetech" target="_blank" class="basetech-hover-text-green">basetech</a></p>
</footer>

<script>
// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}


// Toggle between showing and hiding the sidebar when clicking the menu icon
var mySidebar = document.getElementById("mySidebar");

function basetech_open() {
  if (mySidebar.style.display === 'block') {
    mySidebar.style.display = 'none';
  } else {
    mySidebar.style.display = 'block';
  }
}

// Close the sidebar with the close button
function basetech_close() {
    mySidebar.style.display = "none";
}
</script>

</body>
</html>
