
<?php
$userid = filter_input(INPUT_POST ,'usrname');
$password = filter_input(INPUT_POST ,'psw');
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shivang";

// Create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM ftable WHERE passwords='$password' and userid='$userid'";
$sql1 = mysqli_query($conn,"SELECT fullname FROM ftable WHERE passwords='$password' and userid='$userid'");
$sql2 = mysqli_query($conn,"SELECT dob FROM ftable WHERE passwords='$password' and userid='$userid'");
$sql3 = mysqli_query($conn,"SELECT occupation FROM ftable WHERE passwords='$password' and userid='$userid'");
$sql4 = mysqli_query($conn,"SELECT Email FROM ftable WHERE passwords='$password' and userid='$userid'");
//$asd=$_GET['dob'];

$result = $conn->query($sql);
$result1 = mysqli_fetch_row($sql1);
$string1 = $result1[0];//$conn->query($sql1);
$result2 = mysqli_fetch_row($sql2);
$string2 = $result2[0];
$result3 = mysqli_fetch_row($sql3);
$string3 = $result3[0];
$result4 = mysqli_fetch_row($sql4);
$string4 = $result4[0];
$rowcount=mysqli_num_rows($result);


$cookie_name = "username";
$cookie_value = "$userid";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");

$cookie_name = "fullname";
$cookie_value = "$string1";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");

$cookie_name = "email";
$cookie_value = "$string4";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");

$cookie_name = "dob";
$cookie_value = "$string2";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");

$cookie_name = "occupation";
$cookie_value = "$string3";
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");





if ($rowcount == "0") {
   echo "<script type='text/javascript'>alert(' Login Failed! Userid or Password is incorrect')</script><script>
    window.location.href = 'http://localhost/wtpro/firstpage/1.html';
  </script>";
 // $sql = "SELECT * FROM imgtable";
  //$sth = $conn->query($sql);
  //$result=mysqli_fetch_array($sth);
  //echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['image'] ).'"/>,'$rowcount'';
 // echo"$rowcount";  

} else  {
  //echo"$someString";  
  header("Location: http://localhost/wtpro/homepage/1.html?username=$userid&fullname=$string1&dob=$string2&occupation=$string3");
  exit;
}
mysqli_close($conn);
?>
