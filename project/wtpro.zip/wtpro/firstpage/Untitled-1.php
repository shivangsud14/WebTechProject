
<?php
$userid = $_POST['fname'];
$username = filter_input(INPUT_POST ,'userid');
$email = filter_input(INPUT_POST ,'Email');
$bday = filter_input(INPUT_POST ,'Bday');
$occ = filter_input(INPUT_POST ,'occupation');
$password = filter_input(INPUT_POST ,'psw');
//$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
$servername = "localhost";
$dbusername = "root"; 
$dbpassword = "";
$dbname = "shivang";

// Create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO ftable VALUES('$userid','$username','$email','$bday','$occ','$password')";


if (mysqli_query($conn, $sql)) {
  //  fun();
    $msg="Signup Success! Please Log-in";
    echo "<script type='text/javascript'>alert('$msg');
    window.location = ' http://localhost/wtpro/firstpage/1.html';
    </script>";
  //  if(1)
    //{
      //  header("Location: http://localhost/wtpro/firstpage/1.html");
    //}

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";

mysqli_close($conn);
?>
