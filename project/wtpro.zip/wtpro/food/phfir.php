<?php
$look = filter_input(INPUT_POST ,'search');
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shivang";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = "SELECT link FROM recipe where rname like '%$look%'";
$result = $conn->query($sql1);
//$rowcount=mysqli_num_rows($result);
//$row = mysql_fetch_row($result);
//$data=$row[0]+1;
//$val=$rowcount+1;
//$vall="SELECT FLOOR(RAND()*($val))";
//$result2 = $conn->query($vall);
/*$row=mysqli_fetch_row($result2);
$string1 = $row[0];
$sql = "SELECT nuska FROM nuskat where num=$string1";
$resultx = $conn->query($sql);
$rowx=mysqli_fetch_row($resultx);
$stringx = $rowx[0];*/
/*$data = array(); // create a variable to hold the information
while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) !== false){
  $data[] = $row; // add the row in to the results (data) array
}*/
$myArray[] =array();
$num = mysqli_num_rows($result);
for ($i = 0; $i < $num; $i++)
{
    $myArray[] = mysqli_fetch_assoc($result);
}
/*
for ($i = 0; $i < $num; $i++)
{
   // $row = mysqli_fetch_row($myArray);
    echo $myArray[$i];
}*/
$i=0;
foreach($myArray as $product){
    foreach($product as $key[$i] => $val){ 
        echo "$key[$i]: $val";
        $i++;
      // print "  '   '   $val  '    ' ";
    }
}
//if (mysqli_query($conn, $sql)) {
   
    //  fun();
     // $msg="Nuska Upload Success!";
  //    echo $stringx;
    //  if(1)
      //{
        //  header("Location: http://localhost/wtpro/firstpage/1.html");
      //}
  
 // } else {
     // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   //   echo "$result";
  //}
  
  //$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";
  
  mysqli_close($conn);







?>