
<?php
$dname = $_POST['dishname'];
$dtime = filter_input(INPUT_POST ,'dtime');
$cus = filter_input(INPUT_POST ,'Cusine');
$link = filter_input(INPUT_POST ,'url');
$useridold = filter_input(INPUT_POST ,'idid');
//$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
$servername = "localhost";
$dbusername = "root"; 
$dbpassword = "";
$dbname = "shivang";

// Create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$link1=(explode('=',$link));

$sql = "INSERT INTO recipe VALUES('$useridold','$dname','$dtime','$cus','$link1[1]')";


if (mysqli_query($conn, $sql)) {
  //  fun();
    $msg="Upload Success!";
    echo "<script type='text/javascript'>alert('$msg');
    window.location = ' http://localhost/wtpro/food/fsam.php';
    </script>";
  //  if(1)
    //{
      //  header("Location: http://localhost/wtpro/firstpage/1.html");
    //}

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

//$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";

mysqli_close($conn);
?>
