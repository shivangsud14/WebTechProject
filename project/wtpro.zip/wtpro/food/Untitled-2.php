 
<?php
$nus = filter_input(INPUT_POST ,'subject');

$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shivang";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = "SELECT * FROM nuskat";
$result = $conn->query($sql1);
$rowcount=mysqli_num_rows($result);
//$row = mysql_fetch_row($result);
//$data=$row[0]+1;
$val=$rowcount;
$sql = "INSERT INTO nuskat VALUES('$val','$nus')";


if (mysqli_query($conn, $sql)) {
  //  fun();
    $msg="Nuska Upload Success!";
    echo "<script type='text/javascript'>alert('$msg');
    window.location = ' http://localhost/wtpro/food/fsam.php';
    </script>";
  //  if(1)
    //{
      //  header("Location: http://localhost/wtpro/firstpage/1.html");
    //}

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "$result";
}

//$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";

mysqli_close($conn);
?>

<script>
var x=Math.floor((Math.random() * 100) + 1);
</script>
<?php

echo "<script>document.write(x)</script>";

?>