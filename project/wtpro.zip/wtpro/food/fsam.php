<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>forum</title>
    <link rel="stylesheet" href="a.css">
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  </head>
 
  <body id="main" class="basetech-theme-amber " onload="open()">
<div class="topbar col-lg-12">
      <a href="#bar"><span style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776;</span></a>
      <a href="http://localhost/wtpro/homepage/1.html">Home</a>
      <a href="http://localhost/wtpro/about/1.html">About</a>
      <a href="http://localhost/wtpro/FAQ/1.html">FAQ</a>
      <div class="logo">
          <img src="f1.png" alt="abc" style="border-radius:50%;height:50px;width:125px">
      </div>
</div>

<script>
    function getCookie(cname) {
      var name = cname + "=";
      var ca = document.cookie.split(';');
      for(var i = 0; i < ca.length; i++) {
        var c;
        if(ca[i]==='+')
          {
            c='_';
          }
        else{
          c = ca[i];
        }
        while (c.charAt(0) == ' ') {
          c = c.substring(1);
         
        }
        if (c.indexOf(name) == 0) {
          return c.substring(name.length, c.length);
        }
      }
      return "";
    }
    </script>
<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  <img src="f1.png" alt="abc" style="border-radius:50%;height:100px;width:250px"><br>
  <strong style="font-size:30px;color:#ffffcc">Download top recipe books</strong>
  <a href="sample.pdf" download>aaaa</a>
  <a  href="sample.pdf" download>bbb</a>
  <a  href="sample.pdf" download>cccc</a>
</div>

<div class="hero-image col-lg-12">
  <div class="hero-text">
    <h1 style="font-size:50px">GET SET DROOL</h1>
    <p style="font-size:30px">search for recipies</p>
    <form class="search" action="fsam.php" method="POST" enctype="multipart/form-data">
  <input type="text" placeholder="Search.." name="search" style="color:black;">
  <button type="submit"><i class="fa fa-search"></i></button>
</form>
  </div>
</div>
<?php
$look = filter_input(INPUT_POST ,'search');
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shivang";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = "SELECT link FROM recipe where rname like '%$look%' or timec like '%$look%' or cuisine like '%$look%' or userid like '%$look%' ORDER BY RAND() LIMIT 6";
$result = $conn->query($sql1);
//$rowcount=mysqli_num_rows($result);
//$row = mysql_fetch_row($result);
//$data=$row[0]+1;
//$val=$rowcount+1;
//$vall="SELECT FLOOR(RAND()*($val))";
//$result2 = $conn->query($vall);
/*$row=mysqli_fetch_row($result2);
$string1 = $row[0];
$sql = "SELECT nuska FROM nuskat where num=$string1";
$resultx = $conn->query($sql);
$rowx=mysqli_fetch_row($resultx);
$stringx = $rowx[0];*/
/*$data = array(); // create a variable to hold the information
while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) !== false){
  $data[] = $row; // add the row in to the results (data) array
}*/
$myArray[] =array();
$num = mysqli_num_rows($result);
for ($i = 0; $i < $num; $i++)
{
    $myArray[] = mysqli_fetch_assoc($result);
}
/*
for ($i = 0; $i < $num; $i++)
{
   // $row = mysqli_fetch_row($myArray);
    echo $myArray[$i];
}*/
$narr[]=array();
foreach($myArray as $product){
    foreach($product as $key => $val){
        //echo "$key: $val";
      // print "  '   '   $val  '    ' ";
      $narr[]=$val;
    }
}
//echo $narr[1];
//if (mysqli_query($conn, $sql)) {
   
    //  fun();
     // $msg="Nuska Upload Success!";
  //    echo $stringx;
    //  if(1)
      //{
        //  header("Location: http://localhost/wtpro/firstpage/1.html");
      //}
  
 // } else {
     // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   //   echo "$result";
  //}
  
  //$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";
  
  mysqli_close($conn);







?>

<p style="font-size:50px">Your Search Result</p>

    <div class="col-lg-2 expand "  ><iframe width="230" height="200"
src="https://www.youtube.com/embed/<?php print$narr[1]?>">
</iframe></div>
<div class="col-lg-2 expand "  ><iframe width="230" height="200"
src="https://www.youtube.com/embed/<?php print$narr[2]?>">
</iframe></div>
<div class="col-lg-2 expand "  ><iframe width="230" height="200"
src="https://www.youtube.com/embed/<?php print$narr[3]?>">
</iframe></div>
<div class="col-lg-2 expand "  ><iframe width="230" height="200"
src="https://www.youtube.com/embed/<?php print$narr[4]?>">
</iframe></div>
<div class="col-lg-2 expand "  ><iframe width="230" height="200"
src="https://www.youtube.com/embed/<?php print$narr[5]?>">
</iframe></div>
<div class="col-lg-2 expand "  ><iframe width="230" height="200"
src="https://www.youtube.com/embed/<?php print$narr[6]?>">
</iframe></div>

<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shivang";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = "SELECT * FROM nuskat";
$result = $conn->query($sql1);
$rowcount=mysqli_num_rows($result);
//$row = mysql_fetch_row($result);
//$data=$row[0]+1;
$val=$rowcount;
$vall="SELECT FLOOR(RAND()*($val))";
$result2 = $conn->query($vall);
$row=mysqli_fetch_row($result2);
$string1 = $row[0];
$sql = "SELECT nuska FROM nuskat where num=$string1";
$resultx = $conn->query($sql);
$rowx=mysqli_fetch_row($resultx);
$stringx = $rowx[0];

//if (mysqli_query($conn, $sql)) {
   
    //  fun();
     // $msg="Nuska Upload Success!";
  //    echo $stringx;
    //  if(1)
      //{
        //  header("Location: http://localhost/wtpro/firstpage/1.html");
      //}
  
 // } else {
     // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   //   echo "$result";
  //}
  
  //$sql = "SELECT * FROM ftable WHERE passwords='$password' and username='$userid'";
  
  mysqli_close($conn);

?>

<div id="myModal" class="modal">

  <!--Modal content--> 
  <div class="modal-content" style="background-color: #66ffff">
    <span class="close">&times;</span>
    <h3 style="font-size:30px"><i class="fa fa-lightbulb-o" ></i>  Tip of the day...</h3>
    <h2 style="font-size:30px"><?php echo $stringx?></h2>
  </div>

</div>  
<div class="container-fluid text-center">
  <div class="row content">
    <div class="col-lg-2 sidenav2">
      <h3 style="color:black">Recipies by time...</h3>
      <img class="expand" src="BRK.jpg" alt="" style="height:100px;width:180px;border-radius:10px;cursor:pointer" onclick="open2(this.id)" id="BREAKFAST"></img><br><br>
      <img class="expand" src="lunch.JFIF" alt="" style="height:100px;width:180px;border-radius:10px;cursor:pointer"onclick="open2(this.id)" id="LUNCH"></img><br><br>
    <img class="expand" src="snack.jpg" alt="" style="height:100px;width:180px;border-radius:10px;cursor:pointer" onclick="open2(this.id)" id="SNACKS"></img><br><br>
      <img class="expand" src="dinner.JFIF" alt="" style="height:100px;width:180px;border-radius:10px;cursor:pointer"onclick="open2(this.id)" id="DINNER"></img><br><br>

        </div>
    <div class="col-lg-8 text-left">
      <h1>Welcome to Foodzilla</h1>
      <h4>This is a recipe page which would allow the users to browse and upload recipe and share their cooking tips etc,for the ones wishing to share their amazing recipe videos and willing to show their skills in cooking and even for those who are tired of the same recipe and looking for something new and make your life easier</h4>
      <hr>

      <div class="container">
      <div class="row">
    <div class="col-lg-4" style="background-color:yellow; border:solid black; border-radius:20px">
      <p>
      <br> <strong style="font-size:20px">Recipie in mind..Lets share it..</strong>
    </p>

    
    <script >
      var x=getCookie('username');
        var abc = x.valueOf(x).replace("+",' ');
        //document.getElementById('userfrm').value = abc;
    </script>


      <form class="upload" action="Untitled-1.php" method="POST" enctype="multipart/form-data">
     <label for="fname">Dish Name</label>
     <input type="text" id="dname" name="dishname" placeholder="Dish name..">
     <label for="dtime">Dish suitable for.</label>
     <select id="dtime" name="dtime">
       <option value="BREAKFAST">BREAKFAST</option>
       <option value="LUNCH">LUNCH</option>
       <option value="SNACK">SNACK</option>
       <option value="DINNER">DINNER</option>
     </select>

     <label for="Cusine">Cusine</label>
     <select id="Cusine" name="Cusine">
       <option value="Indian">Indian</option>
       <option value="Italian">Italian</option>
       <option value="Mexiacan">Mexiacan</option>
     </select>
     
     <label for="url">URL</label>
     <input type="text" id="url" name="url" placeholder="URL..">
     <input type="hidden" id="olduid" name="idid" value="">
     <script >
        //var abc = x.valueOf(x).replace("+",' ');
        document.getElementById('olduid').value=abc;
    </script>
     <input type="submit" value="UPLOAD">
   </form>
   <p> <br> </p>
    </div>
    <div class="col-lg-1 " ></div>

    <div class="col-lg-5 " style="background-color:yellow; border:solid black; border-radius:20px">
      <p>
      <br> <strong style="font-size:20px">Share your kitchen nuska....</strong>
    </p>
    <form class="upload" action="Untitled-2.php" method="POST" enctype="multipart/form-data">
      <label for="subject">Lets go..</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" value="Submit">
  </form>
  <p> <br><br> </p>
    </div>
  </div>
</div>
    </div>
  <!--  <div class="col-lg-2 sidenav2">
      <h3 style="color:black">Recipies by cusines...</h3>
      <a href="#"><img class="expand " src="1.jpg" alt="" style="height:100px;width:180px;border-radius:10px;"></img><br><br></a>
      <a href="#"><img class="expand" src="1.jpg" alt="" style="height:100px;width:180px;border-radius:10px;"></img><br><br></a>
      <a href="#"><img class="expand" src="1.jpg" alt="" style="height:100px;width:180px;border-radius:10px;"></img><br><br></a>
      <a href="#"><img class="expand" src="1.jpg" alt="" style="height:100px;width:180px;border-radius:10px;"></img><br><br></a>

    </div>-->
  </div>
</div>

<!-- <div class="container" style="padding:32;text-align:center; background-color:grey">
  <div class="basetech-xlarge ">
    <i class="fa fa-facebook-official basetech-hover-opacity"></i>
    <i class="fa fa-instagram basetech-hover-opacity"></i>
    <i class="fa fa-snapchat basetech-hover-opacity"></i>
    <i class="fa fa-pinterest-p basetech-hover-opacity"></i>
    <i class="fa fa-twitter basetech-hover-opacity"></i>
    <i class="fa fa-linkedin basetech-hover-opacity"></i>
 </div>
 <p>Powered by <a href="#" >BaseTech</a></p>
</div> -->

<div class="footer">
  <div style="font-size:30px">
  <a href="#"><i class="fa fa-facebook-official basetech-hover-opacity" style="color:#ffffcc"></i></a>
  <a href="#">  <i class="fa fa-instagram basetech-hover-opacity" style="color:#ffffcc"></i></a>
  <!-- <a href="#">  <i class="fa fa-snapchat basetech-hover-opacity" style="color:#ffffcc"></i></a> -->
  <!-- <a href="#">  <i class="fa fa-pinterest-p basetech-hover-opacity" style="color:#ffffcc"></i></a> -->
  <a href="#">  <i class="fa fa-twitter basetech-hover-opacity" style="color:#ffffcc"></i></a>
  <!-- <a href="#">  <i class="fa fa-linkedin basetech-hover-opacity" style="color:#ffffcc"></i></a> -->
 </div>
 <p style="color:#ffffcc">Powered by <a href="#" style="color:#ffffcc">BaseTech</a></p>
</div>




<div id="myModal2" class="modal">

  <!-- Modal content -->
  <div class="modal-content2" style="background-color:#700CBC;border:solid black;border-radius:20px">
<div class="row">
    <span class="close2">&times;</span>
</div>

    <div class="row">
        <div class="col-sm-3">
          <iframe id="v1" width="100%" ></iframe>
        </div>
        <div class="col-sm-3">

          <iframe id="v2" width="100%" ></iframe>
        </div>
        <div class="col-sm-3">

          <iframe id="v3" width="100%" ></iframe>
        </div>
        <div class="col-sm-3">

          <iframe id="v4" width="100%" ></iframe>
        </div>
</div>
<br>
<div class="row">
    <div class="col-sm-3">

        <iframe id="v5" width="100%" ></iframe>
    </div>
    <div class="col-sm-3">

      <iframe id="v6" width="100%" ></iframe>
    </div>
    <div class="col-sm-3">

      <iframe id="v7" width="100%" ></iframe>
    </div>
    <div class="col-sm-3">
  <iframe id="v8" width="100%" ></iframe>
    </div>
</div>
<br>
<div class="row">
    <div class="col-sm-3">

      <iframe id="v9" width="100%" ></iframe>
    </div>
    <div class="col-sm-3">

  <iframe id="v10" width="100%" ></iframe>    </div>
    <div class="col-sm-3">

        <iframe id="v11" width="100%" ></iframe>
    </div>
    <div class="col-sm-3">

        <iframe id="v12" width="100%" ></iframe>
    </div>
</div>









  </div>

</div>




<?php
//$look = filter_input(INPUT_POST ,'search');
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "shivang";

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = "SELECT link FROM recipe where timec = 'BREAKFAST' ORDER BY RAND() LIMIT 12";
$sql2 = "SELECT link FROM recipe where timec = 'LUNCH' ORDER BY RAND() LIMIT 12";
$sql3 = "SELECT link FROM recipe where timec = 'SNACK' ORDER BY RAND() LIMIT 12";
$sql4 = "SELECT link FROM recipe where timec = 'DINNER' ORDER BY RAND() LIMIT 12";
$result1 = $conn->query($sql1);
$result2 = $conn->query($sql2);
$result3 = $conn->query($sql3);
$result4 = $conn->query($sql4);

$myArray1[] =array();
$num1 = mysqli_num_rows($result1);
for ($i = 0; $i < $num1; $i++)
{
    $myArray1[] = mysqli_fetch_assoc($result1);
}
$myArray2[] =array();
$num2 = mysqli_num_rows($result2);
for ($i = 0; $i < $num2; $i++)
{
    $myArray2[] = mysqli_fetch_assoc($result2);
}
$myArray3[] =array();
$num3 = mysqli_num_rows($result3);
for ($i = 0; $i < $num3; $i++)
{
    $myArray3[] = mysqli_fetch_assoc($result3);
}
$myArray4[] =array();
$num4 = mysqli_num_rows($result4);
for ($i = 0; $i < $num4; $i++)
{
    $myArray4[] = mysqli_fetch_assoc($result4);
}


$narr1[]=array();
foreach($myArray1 as $product1){
    foreach($product1 as $key1 => $val1){
       
      $narr1[]=$val1;
    }
}

$narr2[]=array(12);
foreach($myArray2 as $product2){
    foreach($product2 as $key2 => $val2){
       
      $narr2[]=$val2;
    }
}

$narr3[]=array(12);
foreach($myArray3 as $product3){
    foreach($product3 as $key3 => $val3){
       
      $narr3[]=$val3;
    }
}

$narr4[]=array(12);
foreach($myArray4 as $product4){
    foreach($product4 as $key4 => $val4){
       
      $narr4[]=$val4;
    }
}

  
  mysqli_close($conn);
?>  



<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.body.style.backgroundColor = "rgba(2, 225, 43, 0.4)";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
  document.body.style.backgroundColor ="#FEE12B";
}
</script>

<script type="text/javascript">


function open2(id) {
  var span2 = document.getElementsByClassName("close2")[0];
  span2.onclick = function() {
  modal2.style.display = "none";
      $("#v1").attr("src","")
    $("#v2").attr("src","")
    $("#v3").attr("src","")
    $("#v4").attr("src","")
    $("#v5").attr("src","")
    $("#v6").attr("src","")
    $("#v7").attr("src","")
    $("#v8").attr("src","")
    $("#v9").attr("src","")
    $("#v10").attr("src","")
    $("#v11").attr("src","")
    $("#v12").attr("src","")

}
  var modal2 = document.getElementById("myModal2");
  modal2.style.display = "block";


  
  if(id=="BREAKFAST")

  { $("#v1").attr("src","https://www.youtube.com/embed/<?php print$narr1[1]?>")
    $("#v2").attr("src","https://www.youtube.com/embed/<?php print$narr1[2]?>")
    $("#v3").attr("src","https://www.youtube.com/embed/<?php print$narr1[3]?>")
    $("#v4").attr("src","https://www.youtube.com/embed/<?php print$narr1[4]?>")
    $("#v5").attr("src","https://www.youtube.com/embed/<?php print$narr1[5]?>")
    $("#v6").attr("src","https://www.youtube.com/embed/<?php print$narr1[6]?>")
    $("#v7").attr("src","https://www.youtube.com/embed/<?php print$narr1[7]?>")
    $("#v8").attr("src","https://www.youtube.com/embed/<?php print$narr1[8]?>")
    $("#v9").attr("src","https://www.youtube.com/embed/<?php print$narr1[9]?>")
    $("#v10").attr("src","https://www.youtube.com/embed/<?php print$narr1[10]?>")
    $("#v11").attr("src","https://www.youtube.com/embed/<?php print$narr1[11]?>")
    $("#v12").attr("src","https://www.youtube.com/embed/<?php print$narr1[12]?>")
  }

    else if(id=="LUNCH")
    { 
    $("#v1").attr("src","https://www.youtube.com/embed/<?php print$narr2[1]?>")
    $("#v2").attr("src","https://www.youtube.com/embed/<?php print$narr2[2]?>")
    $("#v3").attr("src","https://www.youtube.com/embed/<?php print$narr2[3]?>")
    $("#v4").attr("src","https://www.youtube.com/embed/<?php print$narr2[4]?>")
    $("#v5").attr("src","https://www.youtube.com/embed/<?php print$narr2[5]?>")
    $("#v6").attr("src","https://www.youtube.com/embed/<?php print$narr2[6]?>")
    $("#v7").attr("src","https://www.youtube.com/embed/<?php print$narr2[7]?>")
    $("#v8").attr("src","https://www.youtube.com/embed/<?php print$narr2[8]?>")
    $("#v9").attr("src","https://www.youtube.com/embed/<?php print$narr2[9]?>")
    $("#v10").attr("src","https://www.youtube.com/embed/<?php print$narr2[10]?>")
    $("#v11").attr("src","https://www.youtube.com/embed/<?php print$narr2[11]?>")
    $("#v12").attr("src","https://www.youtube.com/embed/<?php print$narr2[12]?>")
  }

      else if(id=="SNACKS")
      { 
    $("#v1").attr("src","https://www.youtube.com/embed/<?php print$narr3[1]?>")
    $("#v2").attr("src","https://www.youtube.com/embed/<?php print$narr3[2]?>")
    $("#v3").attr("src","https://www.youtube.com/embed/<?php print$narr3[3]?>")
    $("#v4").attr("src","https://www.youtube.com/embed/<?php print$narr3[4]?>")
    $("#v5").attr("src","https://www.youtube.com/embed/<?php print$narr3[5]?>")
    $("#v6").attr("src","https://www.youtube.com/embed/<?php print$narr3[6]?>")
    $("#v7").attr("src","https://www.youtube.com/embed/<?php print$narr3[7]?>")
    $("#v8").attr("src","https://www.youtube.com/embed/<?php print$narr3[8]?>")
    $("#v9").attr("src","https://www.youtube.com/embed/<?php print$narr3[9]?>")
    $("#v10").attr("src","https://www.youtube.com/embed/<?php print$narr3[10]?>")
    $("#v11").attr("src","https://www.youtube.com/embed/<?php print$narr3[11]?>")
    $("#v12").attr("src","https://www.youtube.com/embed/<?php print$narr3[12]?>")
  }

        else if(id=="DINNER")
        {
    $("#v1").attr("src","https://www.youtube.com/embed/<?php print$narr3[1]?>")
    $("#v2").attr("src","https://www.youtube.com/embed/<?php print$narr3[2]?>")
    $("#v3").attr("src","https://www.youtube.com/embed/<?php print$narr3[3]?>")
    $("#v4").attr("src","https://www.youtube.com/embed/<?php print$narr3[4]?>")
    $("#v5").attr("src","https://www.youtube.com/embed/<?php print$narr3[5]?>")
    $("#v6").attr("src","https://www.youtube.com/embed/<?php print$narr3[6]?>")
    $("#v7").attr("src","https://www.youtube.com/embed/<?php print$narr3[7]?>")
    $("#v8").attr("src","https://www.youtube.com/embed/<?php print$narr3[8]?>")
    $("#v9").attr("src","https://www.youtube.com/embed/<?php print$narr3[9]?>")
    $("#v10").attr("src","https://www.youtube.com/embed/<?php print$narr3[10]?>")
    $("#v11").attr("src","https://www.youtube.com/embed/<?php print$narr3[11]?>")
    $("#v12").attr("src","https://www.youtube.com/embed/<?php print$narr3[12]?>")
  }





}
</script>

<script type="text/javascript">
  var modal = document.getElementById("myModal");
  var span = document.getElementsByClassName("close")[0];
  span.onclick = function() {
  modal.style.display = "none";
}
function open() {
  modal.style.display = "block";
}
</script>






</body>
</html>
