<!DOCTYPE html>
<html>
<head>
  <meta charset "utf-8">
  <meta name = "viewport" content = "width=device-width,initial-scale=1">
  <title>Kitty party</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href = "style.css" rel = "stylesheet">

</head>
<body data-spy="scroll" data-target="btn" data-offset="50"style = "background:#efefef">
<!--navigation bar -->
<div class = "bgimg">
<div class="topbar col-lg-12">

      <!-- <a href="#bar"><span style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776;</span></a> -->
        <a href="http://localhost/wtpro/homepage/1.html"> <img src="logo.png" alt="logo" style="border-radius:80%;height:25px;width:35px"></a>
        <a href="http://localhost/wtpro/about/1.html">About</a>
        <a href="http://localhost/wtpro/privacy/1.html">Privacy Policy</a>
        <a href="http://localhost/wtpro/FAQ/1.html">FAQ</a>
      
</div>

<div class = "container text-center hearderset">
  <h1>WELCOME TO THE KITTY PARTY WEBSITE</h1>
  <h2>Click here to get the information about a particular kitty</h2>
  <button class = "btn btn-warning text-white btn-lg"><a href="#section1">HERE</a></button>
</div>

</div>
<section class = "container ourfeatures text-center">
  <h1>Features</h1>
  <h4>Party and fun page page where women can host kitty party or herself can join the parties hosted<br>
This is for the people who are willing to interact with a lot of people<h4>
    <br></br>
    <br></br>
    <br></br>

<div class = "row">
  <div class = "col-lg-4 col-md-4 col-sm-4 col-10 d-block m-auto">
  <h2>HOST</h2>
  <p>This is to the ones who is willing to organise

a kitty party<br><br></p>
    <p>Click here to host</p>
    <button class = "btn btn-success" data-target = "#mymodel" data-toggle = "modal">HOST</button>
    <div class = "modal" id = "mymodel">
      <div class = "modal-dialog">
        <div class = "modal-content" style="height:576px;width: 350px">
            <div class = "modal-header">
              <button type = "button" class = "close" data-dismiss = "modal">&times;</button>
              <h3 class = "text-primary" style = "margin-bottom:20px">Hey wassup</h3>


            </div>
            <div class = "modal-body">
              <form class="upload" action="host.php" method="POST" enctype="multipart/form-data">

                <label for = "ktname">NAME</label>
                <input type="text" id="ktname" name="ktname"class ="form-control" >
                  <br></br>
                <label for="dtime">TIMING</label>
                <select id="ktime" name="ktime"class = "form-control">
                  <option value="MORINING">MORINING</option>
                  <option value="AFTERNOON">AFTERNOON</option>
                  <option value="EVENING">EVENING</option>
                  <option value="NIGHT">NIGHT</option>
                </select>
                  <br></br>
                  <strong>DATE</strong>
                   <br></br><input type="date" name="ktdate" class="form-control">
                   <br></br>
             <label for="venue">VENUE</label>
             <!-- <br></br> -->
             <input type="text" id="venue" name="venue" class = "form-control">
             <br></br>

             <input type="submit" value="HOST">
           </form>


            </div>

          </div>
        </div>

      </div>
    </div>




    
  <div class = "col-lg-4 col-md-4 col-sm-4 col-10 d-block m-auto">
  <h2>UPCOMING</h2>
  <p>check the upcoming kitty parties that

are being organised<br><br></p>
    <p>Click here to check upcoming kitties</p>
    <button class = "btn btn-success" data-target = "#mymodel2" data-toggle = "modal">UPCOMING</button>
    <div class = "modal" id = "mymodel2">
      <div class = "modal-dialog">
        <div class = "modal-content">
            <div class = "modal-header">
              <h3 class = " text-primary">Hey wassup</h3>
              <button type = "button" class = "close" data-dismiss = "modal">&times;</button>
            </div>
            <div class = "modal-body">
              <table style="width:100%">
                <caption>UPCOMING KITTIES</caption>
                <tr>
                  <th>DATE</th>
                  <th>VENUE</th>
                  <th>TIMING</th>
                </tr>
                <?php
                  $conn = mysqli_connect("localhost", "root", "", "shivang");
                    // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }
                  $sql = "SELECT DATES,VENUE,TIMING FROM kittyhost WHERE  DATES > cast(now() as date)";
                  $result = $conn->query($sql);
                  if ($result->num_rows > 0) {
                  // output data of each row
                  while($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . $row["DATES"]. "</td><td>" . $row["VENUE"] . "</td><td>". $row["TIMING"]. "</td></tr>";
                  }
                  echo "</table>";
                  } else { echo "0 results"; }
                  $conn->close();
                  ?>
                </table>



            </div>

        </div>

      </div>
    </div>

  </div>
  <!-- </div> -->
  <div class = "col-lg-4 col-md-4 col-sm-4 col-10 d-block m-auto">
  <h2>REQUEST</h2>
  <p>Booring weekend?<br>

Then click here below to request and join a party</p>
    <p>Click here to request</p>
  <button class = "btn btn-success" data-target = "#mymodel3" data-toggle = "modal">REQUEST</button>
    <div class = "modal" id = "mymodel3">
      <div class = "modal-dialog">
        <div class = "modal-content" style="height:730px;width: 350px">
            <div class = "modal-header">
              <button type = "button" class = "close" data-dismiss = "modal">&times;</button>
              <h3 class = "text-primary" style = "margin-bottom:20px">Hey wassup</h3>


            </div>
            <div class = "modal-body" style = "height:1000px">
                <table style="width:100%">
                    <caption>UPCOMING KITTIES</caption>
                    <tr>
                      <th>DATE</th>
                      <th>VENUE</th>
                      <th>TIMING</th>
                    </tr>
                    <?php
                  $conn = mysqli_connect("localhost", "root", "", "shivang");
                    // Check connection
                  if ($conn->connect_error) {
                  die("Connection failed: " . $conn->connect_error);
                  }
                  $sql = "SELECT DATES,VENUE,TIMING FROM kittyhost WHERE  DATES > cast(now() as date)";
                  $result = $conn->query($sql);
                  if ($result->num_rows > 0) {
                  // output data of each row
                  while($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . $row["DATES"]. "</td><td>" . $row["VENUE"] . "</td><td>". $row["TIMING"]. "</td></tr>";
                  }
                  echo "</table>";
                  } else { echo "0 results"; }
                  $conn->close();
                  ?>
    </table>
              <form class="upload" action="req.php" method="POST" enctype="multipart/form-data">

                <label for = "reqktname">NAME</label>
                <input type="text" id="reqktname" name="reqname"class ="form-control">
                  <br></br>
                <label for="reqkttime">TIMING</label>
                <select id="reqktime" name="reqtime"class = "form-control">
                  <option value="REQMORINING">MORINING</option>
                  <option value="REQAFTERNOON">AFTERNOON</option>
                  <option value="REQEVENING">EVENING</option>
                  <option value="REQNIGHT">NIGHT</option>
                </select>
                <br></br>
                <strong>DATE</strong>
                 <br></br><input type="date" name="reqdate" class="form-control">
                 <br></br>

             <label for="reqvenue">VENUE</label>
             <!-- <br></br> -->
             <input type="text" id="reqvenue" name="reqvenue" class = "form-control">
             <br></br>

             <input type="submit" value="REQUEST">
           </form>
            </div>

          </div>
        </div>

      </div>

  </div>
</div>
</section>

<div class="footer" id = "section1">
  <div style="font-size:30px">
  <a href="#"><i class="fa fa-facebook-official " style="color:#ffffcc"></i></a>
  <a href="#">  <i class="fa fa-instagram " style="color:#ffffcc"></i></a>
  <!-- <a href="#">  <i class="fa fa-snapchat " style="color:#ffffcc"></i></a> -->
  <!-- <a href="#">  <i class="fa fa-pinterest-p " style="color:#ffffcc"></i></a> -->
  <a href="#">  <i class="fa fa-twitter " style="color:#ffffcc"></i></a>
  <!-- <a href="#">  <i class="fa fa-linkedin " style="color:#ffffcc"></i></a> -->
 </div>
 <p style="color:#ffffcc">Powered by <a href="#" style="color:#ffffcc">BaseTech</a></p>
</div>









</body>
</html>
